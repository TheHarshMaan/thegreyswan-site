"""
Reviewer Pulse: public evidence of a researcher's peer-review activity. Phase 1 reads the public ORCID record.

What it establishes, and what it doesn't
  - A peer-review item on an ORCID record can only be added by the organisation that ran the review (a publisher, a
    journal system, a recognition service) with the researcher's permission: researchers can't type one in. So each
    item is evidence that a review took place, for that organisation, around that date.
  - It doesn't establish subject expertise (a journal can cover many subjects), the quality of the review, or whether
    the person is available now. Most peer review is never made public, so finding nothing proves nothing.
  - This evidence is shown alongside the Reviewer Finder's ranking, never counted in it.

Each record keeps its provenance: source (ORCID), the organisation that asserted it, the record's put-code and path,
the review's DOI if given, the ISSN from its group id, the journal title if the ISSN resolves in OpenAlex (the ISSN is
kept when it doesn't), the date exactly as given (year, month or day), and when it was retrieved.

Identity: an ORCID iD is a strong identifier but can be mistyped or attached to the wrong profile. The record's
public name is compared with the person's name; a mismatch means the reviews are not shown for this person. Where the
iD came from (the manuscript, or the researcher's OpenAlex profile) is kept.

Format: ORCID public API v3.0, GET https://pub.orcid.org/v3.0/{orcid}/record (Accept: application/json). Its
activities-summary/peer-reviews holds groups (one per journal, review-group-id such as issn:1234-5678), each holding
peer-review-group items (one per review, with ORCID's own de-duplication of copies from several sources), each holding
peer-review-summary copies. Older records put the summaries directly in the group; both are read.
"""
import asyncio
import re
from datetime import datetime, timezone

import idcheck as ic

ORCID_API = ic.ORCID_API
RECENT_YEARS = 3
REVIEW_ROLES = {"reviewer"}
EDITORIAL_ROLES = {"editor", "chair", "organizer", "member"}
ISSN_RE = re.compile(r"^(\d{4})-?(\d{3}[\dXx])$")

LABELS = {
    "recent": "Verified recent reviewing",
    "historical": "Verified reviewing, not recent",
    "undated": "Verified reviewing, dates not given",
    "editorial": "Editorial service only",
    "none": "No public review records",
    "no_orcid": "Not checked: no ORCID iD",
    "invalid": "Not checked: ORCID iD isn't valid",
    "mismatch": "Not shown: ORCID name doesn't match",
    "not_found": "Not checked: ORCID iD not found",
    "rate_limited": "Couldn't check: ORCID is busy",
    "unavailable": "Couldn't check: ORCID didn't answer",
    "unreadable": "Couldn't read the ORCID record",
}
LIMIT_NONE = ("Most peer review is never made public, so no record here doesn't mean they haven't reviewed.")
LIMIT_SCOPE = ("A record shows a review took place for that journal or organisation. It doesn't show the subject "
               "reviewed, the quality of the review, or whether they're available now.")


def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _v(x):
    """ORCID wraps many values as {"value": …}."""
    if isinstance(x, dict):
        return x.get("value")
    return x


def norm_doi(text):
    t = (text or "").strip()
    t = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", t, flags=re.IGNORECASE)
    return t.lower() if t.startswith("10.") else ""


def issn_of(group_id):
    g = (group_id or "").strip()
    if not g.lower().startswith("issn:"):
        return ""
    m = ISSN_RE.match(g[5:].strip())
    return f"{m.group(1)}-{m.group(2).upper()}" if m else ""


def fuzzy_date(d):
    """(text, year) exactly as given: '2025', '2025-03' or '2025-03-14'; (None, None) when not given."""
    if not isinstance(d, dict):
        return None, None
    y, m, day = _v(d.get("year")), _v(d.get("month")), _v(d.get("day"))
    if not (y and str(y).isdigit()):
        return None, None
    text = str(y)
    if m and str(m).isdigit():
        text += f"-{int(m):02d}"
        if day and str(day).isdigit():
            text += f"-{int(day):02d}"
    return text, int(y)


def record_name(data):
    """The public names on an ORCID record: given + family, and the credit name, if public."""
    person = (data or {}).get("person") or {}
    nm = person.get("name") or {}
    names = []
    full = " ".join(x for x in (_v(nm.get("given-names")), _v(nm.get("family-name"))) if x)
    if full.strip():
        names.append(full.strip())
    credit = _v(nm.get("credit-name"))
    if credit:
        names.append(credit)
    for o in ((person.get("other-names") or {}).get("other-name") or []):
        if isinstance(o, dict) and o.get("content"):
            names.append(o["content"])
    return names


def summaries_in(peer_reviews):
    """[(review summaries, ORCID group id)], one entry per review. Defensive about shape."""
    out = []
    groups = (peer_reviews or {}).get("group") if isinstance(peer_reviews, dict) else None
    if not isinstance(groups, list):
        return out
    for g in groups:
        if not isinstance(g, dict):
            continue
        gid = ""
        for e in ((g.get("external-ids") or {}).get("external-id") or []):
            if isinstance(e, dict) and e.get("external-id-type") == "peer-review":
                gid = e.get("external-id-value") or ""
        inner = g.get("peer-review-group")
        if isinstance(inner, list):                         # v3.0: group -> review -> copies
            for review in inner:
                copies = [s for s in (review or {}).get("peer-review-summary") or [] if isinstance(s, dict)]
                if copies:
                    out.append((copies, gid))
        else:                                               # older layout: group -> copies
            copies = [s for s in g.get("peer-review-summary") or [] if isinstance(s, dict)]
            for s in copies:
                out.append(([s], gid))
    return out


def parse_record(data, orcid, retrieved_at):
    """The peer-review activities on a public ORCID record, one per review, with provenance."""
    acts = (data or {}).get("activities-summary") or {}
    raw = summaries_in(acts.get("peer-reviews"))
    records = []
    for copies, gid in raw:
        public = [s for s in copies if (s.get("visibility") or "public") == "public"]
        if not public:
            continue
        s = sorted(public, key=lambda x: str(x.get("display-index") or "0"), reverse=True)[0]
        group_id = s.get("review-group-id") or gid or ""
        date_text, year = fuzzy_date(s.get("completion-date") or s.get("review-completion-date"))
        doi = ""
        for e in ((s.get("external-ids") or s.get("review-identifiers") or {}).get("external-id") or []):
            if isinstance(e, dict) and (e.get("external-id-type") or "").lower() == "doi" \
                    and (e.get("external-id-relationship") or "self") == "self":
                doi = norm_doi(e.get("external-id-value") or _v(e.get("external-id-url")) or "")
                if doi:
                    break
        review_url = _v(s.get("review-url")) or ""
        if not doi:
            doi = norm_doi(review_url)
        org = s.get("convening-organization") or {}
        dis = org.get("disambiguated-organization") or {}
        src = s.get("source") or {}
        role = (s.get("reviewer-role") or "").lower()
        records.append({
            "evidence_class": "editorial_service" if role in EDITORIAL_ROLES else "verified_peer_review",
            "source": {"name": "ORCID", "asserted_by": _v(src.get("source-name")) or "",
                       "assertion_origin": _v(src.get("assertion-origin-name")) or "",
                       "record_id": str(s.get("put-code") or ""), "path": s.get("path") or "",
                       "api_url": f"{ORCID_API}{s['path']}" if s.get("path") else "",
                       "url": f"https://orcid.org/{orcid}", "retrieved_at": retrieved_at, "copies": len(public)},
            "activity": {"group_id": group_id, "issn": issn_of(group_id), "journal": None, "journal_openalex": None,
                         "organisation": org.get("name") or "",
                         "organisation_id": (dis.get("disambiguated-organization-identifier") or ""),
                         "organisation_id_source": (dis.get("disambiguation-source") or ""),
                         "date": date_text, "year": year, "role": role or None,
                         "review_type": (s.get("review-type") or "").lower() or None,
                         "review_doi": doi or None, "review_url": review_url or None},
        })
    # The same review deposited twice under different groups: one record, both copies noted
    seen, out = {}, []
    for r in records:
        d = r["activity"]["review_doi"]
        if d and d in seen:
            seen[d]["source"]["copies"] += r["source"]["copies"]
            continue
        if d:
            seen[d] = r
        out.append(r)
    out.sort(key=lambda r: (r["activity"]["date"] or ""), reverse=True)
    return out


async def resolve_issns(fetch, issns):
    """ISSN -> {title, openalex id, publisher} from OpenAlex. ISSNs that don't resolve are simply absent."""
    found, ok = {}, True
    issns = sorted(set(i for i in issns if i))
    for k in range(0, len(issns), 50):
        chunk = issns[k:k + 50]
        status, data = await fetch.get(fetch.openalex("/sources", filter="issn:" + "|".join(chunk), per_page=50,
                                                      select="id,display_name,issn,issn_l,host_organization_name"))
        if status != 200 or not data:
            ok = False
            continue
        for src in data.get("results") or []:
            listed = {x.upper() for x in (src.get("issn") or []) + [src.get("issn_l") or ""] if x}
            for i in chunk:
                if i in listed and i not in found:
                    found[i] = {"title": src.get("display_name") or "", "openalex": ic.short_id(src.get("id")),
                                "publisher": src.get("host_organization_name") or ""}
    return found, ok


def summarise(records, today, recent_years=RECENT_YEARS):
    reviews = [r for r in records if r["evidence_class"] == "verified_peer_review"]
    editorial = [r for r in records if r["evidence_class"] == "editorial_service"]
    years = [r["activity"]["year"] for r in reviews if r["activity"]["year"]]
    latest = max(years) if years else None
    journals = {}
    for r in reviews:
        a = r["activity"]
        key = a["issn"] or a["group_id"] or a["organisation"] or "unknown"
        j = journals.setdefault(key, {"title": a["journal"], "issn": a["issn"], "organisation": a["organisation"],
                                      "count": 0, "latest": None})
        j["count"] += 1
        if a["year"] and (not j["latest"] or a["year"] > j["latest"]):
            j["latest"] = a["year"]
    if reviews:
        state = "recent" if latest and latest >= today.year - recent_years else "historical" if latest else "undated"
    elif editorial:
        state = "editorial"
    else:
        state = "none"
    return {"state": state, "label": LABELS[state], "reviews": len(reviews), "editorial": len(editorial),
            "latest_year": latest, "recent_years": recent_years,
            "journals": sorted(journals.values(), key=lambda j: (-j["count"], -(j["latest"] or 0)))}


def empty(state, orcid="", association="", limitations=None):
    return {"orcid": orcid, "association": association, "state": state, "label": LABELS[state],
            "identity": {"status": "unresolved", "basis": []}, "records": [], "summary": None,
            "limitations": limitations or [], "retrieved_at": now_iso(),
            "sources_checked": ["ORCID public record"] if state not in ("no_orcid", "invalid") else []}


async def pulse_for(fetch, orcid, name, association, today, recent_years=RECENT_YEARS):
    """Everything Reviewer Pulse shows for one person. association: where the ORCID iD came from."""
    o = ic.clean_orcid(orcid or "")
    if not o:
        return empty("no_orcid", "", association, ["No ORCID iD is known for this person, so their public "
                                                   "reviewing record wasn't checked."])
    if not ic.orcid_valid(o):
        return empty("invalid", o, association, ["The ORCID iD's check digit is wrong, so it can't be a real iD."])
    retrieved = now_iso()
    status, data = await fetch.get(f"{ORCID_API}/{o}/record", {"Accept": "application/json"})
    if status == 404:
        return empty("not_found", o, association, ["ORCID has no record with this iD."])
    if status == 429:
        return empty("rate_limited", o, association, ["ORCID asked us to slow down. Try again in a minute."])
    if status != 200 or not isinstance(data, dict):
        return empty("unavailable", o, association, ["ORCID didn't answer, so nothing can be said either way."])
    try:
        names = record_name(data)
        records = parse_record(data, o, retrieved)
    except Exception:                                          # noqa: BLE001 - an unexpected shape must not break the page
        return empty("unreadable", o, association, ["The ORCID record came back in an unexpected form."])
    basis = [association] if association else []
    if names:
        best = max(ic.name_match(name or "", n) for n in names)
        if name and best < 0.75:
            out = empty("mismatch", o, association,
                        [f"The ORCID record is in the name of {names[0]}, not {name}. Its review records aren't shown "
                         "for this person. Check that the right iD is attached."])
            out["identity"] = {"status": "mismatch", "basis": basis + [f"ORCID name: {names[0]}"]}
            out["retrieved_at"] = retrieved
            return out
        identity = {"status": "confirmed", "basis": basis + ["name on the ORCID record matches"]}
        limits = []
    else:
        identity = {"status": "probable", "basis": basis}
        limits = ["The name on this ORCID record isn't public, so the link to this person couldn't be double-checked."]
    issns = [r["activity"]["issn"] for r in records if r["activity"]["issn"]]
    if issns:
        found, ok = await resolve_issns(fetch, issns)
        for r in records:
            j = found.get(r["activity"]["issn"])
            if j:
                r["activity"]["journal"], r["activity"]["journal_openalex"] = j["title"], j["openalex"]
        if not ok:
            limits.append("Some journal names couldn't be looked up; their ISSNs are shown instead.")
    summary = summarise(records, today, recent_years)
    limits.append(LIMIT_NONE if summary["state"] == "none" else LIMIT_SCOPE)
    if summary["state"] == "none":
        limits.append("Only ORCID was checked.")
    return {"orcid": o, "association": association, "state": summary["state"], "label": summary["label"],
            "identity": identity, "records": records, "summary": summary, "limitations": limits,
            "retrieved_at": retrieved, "sources_checked": ["ORCID public record"]}


async def pulse_many(fetch, people, today, recent_years=RECENT_YEARS):
    """people: [(key, orcid, name, association)] -> {key: pulse}"""
    res = await asyncio.gather(*(pulse_for(fetch, o, n, a, today, recent_years) for _, o, n, a in people))
    return {k: r for (k, _, _, _), r in zip(people, res)}


def one_line(p):
    """A plain one-line summary for reports."""
    if not p:
        return ""
    s = p.get("summary")
    if not s or not s["reviews"]:
        return p["label"]
    js = "; ".join(f"{j['title'] or ('ISSN ' + j['issn'] if j['issn'] else j['organisation'] or 'journal not named')} "
                   f"({j['count']})" for j in s["journals"][:4])
    return (f"{s['reviews']} public review record{'s' if s['reviews'] != 1 else ''} in ORCID"
            f"{', latest ' + str(s['latest_year']) if s['latest_year'] else ''}: {js}. Checked {p['retrieved_at'][:10]}.")
